
((Get-Host).UI.RawUI).WindowTitle = "SnsSqlitePsModule - Created by Svetoslav Savov";
((Get-Host).UI.RawUI).BufferSize.Width = 120;
((Get-Host).UI.RawUI).BufferSize.Height = 50;
((Get-Host).UI.RawUI).WindowSize.Width = 120;
((Get-Host).UI.RawUI).WindowSize.Height = 50;
((Get-Host).UI.RawUI).MaxWindowSize.Width = 120;
((Get-Host).UI.RawUI).MaxWindowSize.Height = 50;

If ([System.Environment]::UserInteractive)
{
##### Generate The Warning Message
[System.String]$strWarning = '';
[System.String]$strWarning += "`r`n$('*' * 100)`r`n*$(' ' * 98)*`r`n";
[System.String]$strWarning += "*$(' ' * 30)SnsSqlitePsModule - PowerShell Module$(' ' * 31)*`r`n*$(' ' * 98)*`r`n";
[System.String]$strWarning += "*$(' ' * 9)AUTHOR:    Svetoslav Nedyalkov Savov (svesavov@hotmail.com)$(' ' * 30)*`r`n";
[System.String]$strWarning += "*$(' ' * 9)COPYRIGHT: (c) 2020 Svetoslav Nedyalkov Savov, all rights reserved.$(' ' * 22)*`r`n";
[System.String]$strWarning += "*$(' ' * 9)THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK$(' ' * 9)*`r`n";
[System.String]$strWarning += "*$(' ' * 9)OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.$(' ' * 15)*`r`n";
[System.String]$strWarning += "*$(' ' * 98)*`r`n$('*' * 100)`r`n`r`n";

##### Throw The Warning
Write-Warning "$($strWarning)";

##### Reset The Variable
Remove-Variable -Force -WhatIf:$false -Confirm:$false -ErrorAction "SilentlyContinue" -Name "strWarning";
}
